package Model;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Rook {
	
	BufferedImage blackRook,whiteRook;
	
	public Rook() {
		setImage();
	}
	
	public void setImage() {
		try {
			blackRook = ImageIO.read(new File("D:\\IDO\\My Documents\\Uni\\Rmit\\Year 2\\SEF\\Assignment\\Media\\BlackRook.jpg"));
			whiteRook = ImageIO.read(new File("D:\\IDO\\My Documents\\Uni\\Rmit\\Year 2\\SEF\\Assignment\\Media\\WhiteRook.jpg"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public BufferedImage getImage(String color) {
		if(color.matches("white")) {
			return whiteRook;
		}
		return blackRook;
	}
	
	public boolean validMove(int tempRow, int tempCol, int currentRow, int currentCol) {
		if (currentRow == tempRow && (currentCol == tempCol + 2 || currentCol == tempCol - 2)) {
			return true;
		}else if(currentCol == tempCol && (currentRow == tempRow + 2 || currentRow == tempRow -2) ) {
			return true;
		}
		return false;
	}
}
