package Client;

import Model.GameEngine;
import View.Frame;

public class Driver {

	public static void main(String[] args) {
		GameEngine gameEngine = new GameEngine();
	}

}
